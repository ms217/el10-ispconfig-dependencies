---
name: Support Question
about: If you have a question 💬, please check out our Mailing lists or other support channels!

---

--------------^ Click "Preview" for a nicer view!
We primarily use GitHub as an issue tracker; for usage and support questions, please check out these resources below. Thanks!

---

* Mailing list: https://lists.rspamd.com/mailman/listinfo (you can subscribe on that page or browse the archives)
* Telegram channel: http://t.me/rspamd
* Also have a look at the following page for more information on how to get support:
  https://rspamd.com/support.html
