# Project Authors and Contributors

Rspamd was created by [Vsevolod Stakhov](https://github.com/vstakhov).

## Authors

* [Vsevolod Stakhov](https://github.com/vstakhov)

## Developers

* [Alexander Moisseev](https://github.com/moisseev)
* [Andrew Lewis](https://github.com/fatalbanana)

## Alumni Developers

* [Mikhail Galanin](https://github.com/negram)

## Significant contributors

* [Steve Freegard](https://github.com/smfreegard)
* [Alexey Savelyev](https://github.com/AlexeySa)
* [Anna Stakhova](https://github.com/AnnaStakhova)
* [Anton Yuzhaninov](https://github.com/citrin)

<https://github.com/rspamd/rspamd/graphs/contributors>

## Special thanks to

* [Mimecast](https://mimecast.com)
* [Locaweb](https://locaweb.com.br)
